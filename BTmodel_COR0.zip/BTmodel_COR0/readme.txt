cd in BTmodel_COR

Open Matlab

addpath(genpath('./'))

cd main

BT_main(0);
